require('./src/js/ngDatepicker.min.js');
module.exports = 'ng-datepicker';
